<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Title -->
    <title><?php echo $__env->yieldContent('title', 'Dog Crew Asd'); ?></title>

    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="57x57" href="<?php echo e(asset("storage/apple-icon-57x57.png")); ?>">
    <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(asset("storage/apple-icon-60x60.png")); ?>">
    <link rel="apple-touch-icon" sizes="72x72" href="<?php echo e(asset("storage/apple-icon-72x72.png")); ?>">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset("storage/apple-icon-76x76.png")); ?>">
    <link rel="apple-touch-icon" sizes="114x114" href="<?php echo e(asset("storage/apple-icon-114x114.png")); ?>">
    <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(asset("storage/apple-icon-120x120.png")); ?>">
    <link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(asset("storage/apple-icon-144x144.png")); ?>">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(asset("storage/apple-icon-152x152.png")); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset("storage/apple-icon-180x180.png")); ?>">
    <link rel="icon" type="image/png" sizes="192x192"  href="<?php echo e(asset("storage/android-icon-192x192.png")); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset("storage/favicon-32x32.png")); ?>">
    <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(asset("storage/favicon-96x96.png")); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset("storage/favicon-16x16.png")); ?>">
    <link rel="manifest" href="/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">

    <!--Icons-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" />

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Sen&family=Ubuntu:wght@400;500&display=swap" rel="stylesheet"> 

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">


</head>
<body>
    <div id="app">

        <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main class="mt_120">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

    
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <?php echo $__env->yieldContent('script'); ?>

</body>
</html>


<?php /**PATH /Users/emanuelecannone/Progetti/DogCrewAsd/resources/views/layouts/app.blade.php ENDPATH**/ ?>