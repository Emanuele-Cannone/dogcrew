<footer>
    <div class="footer_container">
        <p>Seguimi sui social per rimanere aggiornato sui prossimi eventi</p>
        <ul>
            <li>
                <a href="https://www.facebook.com/dogcrewasd" target="_blank">
                    <img src="{{asset('storage/facebook_icon.png')}}" alt="facebook">
                </a>
            </li>
            <li>
                <a href="https://www.instagram.com/dogcrew_asd" target="_blank">
                    <img src="{{asset('storage/instagram_icon.png')}}" alt="instagram">
                </a>
            </li>
            <li>
                <a href="http://m.me/dogcrewasd" data-text="Ciao, ho appena visto il tuo sito" target="_blank">
                    <img src="{{asset('storage/messenger_icon.png')}}" alt="messenger">
                </a>
            </li>
            <li>
                <a href="whatsapp://send" data-text="Dai uno sguardo a questo post:" target="_blank">
                    <img src="{{asset('storage/whatsapp_icon.png')}}" alt="whatsapp">
                </a>
            </li>
        </ul>
    </div>
</footer>