@extends('layouts.app')
@section('title')
@section('content')
  <div id="welcomePage">
    <div class="container">
      <div class="row justify-content-center">
  
        <div class="col-md-8 col-lg-6">
          <div class="card">
            <div class="card-header text-center font-weight-bold">
              Nuova categoria
            </div>
            <div class="card-body">
                ciao
            </div>
          </div>
        </div>
  
      </div>
    </div>
  
  </div>
  {{-- <script src="{{ asset('js/welcome.js') }}"></script> --}}

@endsection
